# xascii
photo to ascii code



![Screenshot 2025-03-09 043618](https://github.com/user-attachments/assets/f454074c-9d38-4c29-ab60-ac15876c02fb)
